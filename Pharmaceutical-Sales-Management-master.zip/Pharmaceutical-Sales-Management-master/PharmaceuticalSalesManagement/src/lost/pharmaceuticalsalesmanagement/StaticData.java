package lost.pharmaceuticalsalesmanagement;

public class StaticData {
	public static String s = "http://10.0.2.2/", id, pawd, rank, area;
}
