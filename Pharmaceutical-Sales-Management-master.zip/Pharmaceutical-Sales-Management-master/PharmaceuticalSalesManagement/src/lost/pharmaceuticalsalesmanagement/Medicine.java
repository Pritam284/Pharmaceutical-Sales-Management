package lost.pharmaceuticalsalesmanagement;

public class Medicine {
	String mId, mAmount;
	int price;
	Medicine(String _mId, String _mAmount,int _price) {
		mId = _mId;
		mAmount = _mAmount;
		price = _price;
	}
}
