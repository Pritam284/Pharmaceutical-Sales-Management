Pharmaceutical-Sales-Management
===============================
AUST 3rd year 2nd Semester ISD LAB
===============================
Work for the project::
===============================
Pritam Das

Faiaz Ahsan

Mahir Asef Kabir

MD. Musfiqur Rahman Sanim

===============================
Its a Android based software for MPO's with php scripting in backend
all the information are saved in a web server
